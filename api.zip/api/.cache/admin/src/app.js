const config = {
  locales: ['fr'],
};
const bootstrap = () => {};

export default {
  config,
  bootstrap,
};
