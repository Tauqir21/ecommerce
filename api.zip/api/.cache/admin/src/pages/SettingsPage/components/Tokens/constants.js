export const API_TOKEN_TYPE = 'api-token';
export const TRANSFER_TOKEN_TYPE = 'transfer-token';
