export { default as RelationInput } from './RelationInput';
export * from './RelationInput';
