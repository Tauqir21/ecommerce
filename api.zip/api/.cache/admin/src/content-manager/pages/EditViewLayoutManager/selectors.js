const selectLayout = (state) => state['content-manager_editViewLayoutManager'].currentLayout;

export default selectLayout;
