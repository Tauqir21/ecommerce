const getTrad = (id) => `content-manager.${id}`;

export default getTrad;
