export default {
  COMPONENT: 'component',
  EDIT_FIELD: 'editField',
  FIELD: 'field',
  DYNAMIC_ZONE: 'dynamicZone',
  RELATION: 'relation',
};
