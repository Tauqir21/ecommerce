export const SET_PERMISSIONS = 'ContentManager/RBACManager/SET_PERMISSIONS';
export const RESET_PERMISSIONS = 'ContentManager/RBACManager/RESET_PERMISSIONS';
