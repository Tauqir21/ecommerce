import testData, { permissions } from './data';

export { permissions, testData };
