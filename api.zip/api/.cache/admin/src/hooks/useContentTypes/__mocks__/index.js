export const useContentTypes = jest.fn().mockReturnValue({
  isLoading: false,
  components: [],
  collectionTypes: [],
  singleTypes: [],
});
