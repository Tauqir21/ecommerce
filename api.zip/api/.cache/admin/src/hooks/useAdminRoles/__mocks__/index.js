export const useAdminRoles = jest.fn().mockReturnValue({
  roles: [],
  isLoading: false,
  isError: false,
});
